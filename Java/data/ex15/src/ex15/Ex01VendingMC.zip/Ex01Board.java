package ex15;

public class Ex01Board {

	int boardCnt;
	String title;
	String splTitle;
	String writer;
	int view;
	String contents;
	String date;

}
