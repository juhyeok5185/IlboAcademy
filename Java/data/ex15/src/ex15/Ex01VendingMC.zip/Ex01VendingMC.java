package ex15;

public class Ex01VendingMC {

	String itemName;
	int itemPrice;
	int itemEa;

}
