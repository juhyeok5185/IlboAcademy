package ex15;

public class Ex01User {
	String userName;
	String userId;
	String userPw;
	int userMoney;
	int listNum;
	String[] list;

}
