package ex15;

public class Ex01Transfer {
	String status;
	int money;
	int cnt;
	String name;
	String otherName;
}
