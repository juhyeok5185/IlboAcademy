
public interface SuperPayment {
	void cardName(String name);

	void cardNum(String num);

	void cardExpairy(String expairy);

	void acess(String cardName, String cardNum, String cardExpairy);
}
